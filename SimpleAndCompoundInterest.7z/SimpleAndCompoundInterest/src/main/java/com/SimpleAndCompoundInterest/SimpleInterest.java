package com.SimpleAndCompoundInterest;

public class SimpleInterest extends SettingValues{
	
	double simpleInterest()
	{
		return (principalamount*timeperiod*rateofinterest)/100;
	}

}
